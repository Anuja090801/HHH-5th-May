document.addEventListener("DOMContentLoaded", function() {
    var searchButton = document.getElementById("searchButton");

    searchButton.addEventListener("click", function() {
        search();
    });

    function search() {
        var selectedDisease = document.getElementById("categorySelect").value;
        var table = document.getElementById("resultTable");
        var resultBody = document.getElementById("resultBody");
        var container = document.querySelector(".container");

        // Clear previous results
        resultBody.innerHTML = "";
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Fetch data based on selected disease
        // Example data
        var data = [];

        switch(selectedDisease.toLowerCase()) {
            case "breast cancer":
                data = [
                    { Mild: "	Tamoxifen", Chronic: "Doxorubicin" },
                    { Mild: "letrozol ", Chronic: "Paclitaxel " },
                    { Mild: "Lapatinib ", Chronic: "Capecitabine" },
                    { Mild: "Neratinib ", Chronic: "Cyclophosphamide" },
                    { Mild: "Palbociclib ", Chronic: "Carboplatin " },
                    { Mild: "Abemaciclib ", Chronic: "Evista " },
                    { Mild: "Pertuzumab ", Chronic: "Epirubicin " },
                    { Mild: "Trastuzumab ", Chronic: "Fluorouracil " },
                ];
                break;
                case "pcod":
                    data = [
                      { Mild: "Clomiphene ", Chronic: "Acarbose" },
                      { Mild: " Eflornithine", Chronic: "Desogestrel " },
                      { Mild: " Metformin ", Chronic: "Finasteride" },
                      { Mild: " Metformin ", Chronic: "Flutamide" },
                      { Mild: " Drospirenone ", Chronic: "Letrozole" },
                      { Mild: " Liraglutide", Chronic: " Sibutramine " },
                      { Mild: " Pioglitazone", Chronic: "Drospirenone " },
                      { Mild: "Rosiglitazone ", Chronic: "Ethinylestradiol Plus Levonorgestrel" },
                      { Mild: "Spironolactone", Chronic: " " },
                        ];
                    break;
                  case "thyroid":
                    data = [
                      { Mild: "Levothyroxine ", Chronic: "methimazole  " },
                      { Mild: " liothyronine ", Chronic: "propylthiouracil " },
                      { Mild: "Tirosint ", Chronic: " Vandetanib" },
                      { Mild: "Pazopanib", Chronic: "Liotrex " },
                      { Mild: "Carbimazole ", Chronic: "Triiodothyronine" },
                      { Mild: " Dexamethasone", Chronic: " Thyroxin " },
                      { Mild: "Sunitinib ", Chronic: "Calcitonin  " },
                      { Mild: "Thyrotropin Alfa  ", Chronic: "Sorafenib " },
                        ];
                    break;
                  case "cervical cancer":
                    data = [
                      { Mild: "Acetaminophen  ", Chronic: "Cisplatin" },
                      { Mild: " Ibuprofen  ", Chronic: "Carboplatin" },
                      { Mild: " Naproxen  ", Chronic: "Paclitaxel" },
                      { Mild: " Ondansetron  ", Chronic: "Topotecan" },
                      { Mild: "Metoclopramide  ", Chronic: " Gemcitabine " },
                      { Mild: "Dexamethasone ", Chronic: "Oxaliplati " },
                      { Mild: " Lorazepam   ", Chronic: " Docetaxel" },
                      { Mild: " Diphenhydramine  ", Chronic: " Irinotecan" },
                        ];
                    break;
                  case "uterian fibroids":
                    data = [
                      { Mild: "Halofuginone ", Chronic: "Anastrozole " },
                      { Mild: " Pirfenidone ", Chronic: "Myfembree" },
                      { Mild: " acetaminophen ", Chronic: "Ulipristal Acetate" },
                      { Mild: "mifepristone  ", Chronic: "Oriahnn" },
                      { Mild: "fadrozole ", Chronic: " Leuprolide " },
                      { Mild: " asoprisnil", Chronic: " Ulipristal" },
                      { Mild: "  vilaprisan ", Chronic: " Goserelin" },
                      { Mild: "Tranexamic acid ", Chronic: " Triplorelin" },
                        ];
                    break;
                  default:
                    break;
        }

        // Populate table with fetched data
        for (var i = 0; i < data.length; i++) {
            var row = document.createElement("tr");
            row.innerHTML = "<td>" + data[i].Mild + "</td><td>" + data[i].Chronic + "</td>";
            resultBody.appendChild(row);
        }

        // Show the table
        table.style.display = "table";

        // Add event listener to cells for additional drug details
        var cells = document.querySelectorAll("#resultBody td");
        cells.forEach(function(cell) {
            cell.addEventListener("click", function() {
                var drugName = cell.textContent.trim();
                showDrugDetails(drugName);
            });
        });
    }

    // Function to display additional drug details for the selected medication
    function showDrugDetails(drugName) {
        // Object containing drug details for each medication
        var drugDetails = {
            "Tamoxifen": {
                "Drug Name": "Tamoxifen",
                "Receptor": "Estrogen receptors.",
                "LogP Value": "6.35",
                "Chemical Formula":"C2H29NO",
                "Half Life":"5 to 7 days.",
                "Adverse Effects":"1.leg cramps   \n 2.hair thinning or hair loss. \n3.feeling light headed. \n4.eye problems, such as blurred vision, due to damage of the retina or cataracts. an allergic reaction. \n5. headaches. \n6.diarrhoea. \n7.itchiness on or around the vulval area",
                "Food Interactions":"•	This herb induces CYP3A4 metabolism, which may reduce the serum concentration of tamoxifen. Take with a full glass of water. Take with or without food",
                "Dosage form":"20 to 40 mg orally daily for 5 years; doses greater than 20 mg should be given in divided doses. To reduce the incidence of breast cancer in women at high risk for breast cancer: 20 mg orally daily for 5 years",
                "Marketed preparation":"Nolvadex tablets, . liquid (brand name):  Soltamox",
                "Alternatives":"anastrozole, exemestane, Other SERMs, such as raloxifene, fulvestrant."
            },
            "Doxorubicin": {
                "Drug Name": "Doxorubicin",
                "Receptor": "GPR91 Receptor.",
                "LogP Value": "0.53.",
                "Chemical Formula":"C27H29NO11",
                "Half Life":"20 hours to 48 hours",
                "Adverse Effects":"diarrhoea Nausea Hair loss, Bleeding, Breathlessness Mouth, Haematuria, Tiredness, Melena, Chest pain, Cough, Irregular heartbeat, Pain at the injection site, Painful or difficult urination, Fever, Lungs, Red spots, Sore throat",
                "Food Interactions":"Avoid St. John's Wort. This herb induces CYP3A4 metabolism, which may reduce the serum concentration of doxorubicin. Exercise caution with grapefruit products. Grapefruit inhibits CYP3A4 metabolism, which may increase the serum concentration of doxorubicin",
                "Dosage form":"injectable solution- 2mg/mL powder for injection-10mg,50mg",
                "Marketed preparation":"Adriamycin",
                "Alternatives":"Verzenio (abemaciclib)	Ibrance (palbociclib)"
            },
            "letrozole": {
                "Drug Name": "letrozole",
                "Receptor": "Hormone receptor (HR).",
                "LogP Value": "1.8 –2.95.",
                "Chemical Formula":"C17H11N5",
                "Half Life":"approximately 42h in healthy volunteers, but longer in breast cancer patients ",
                "Adverse Effects":"similar to the menopause such as hot flushes, difficulty sleeping, tiredness and low mood, but these usually improve during the first months of taking it. However, if the symptoms are severe or last longer than a few months",
                "Food Interactions":"Take with or without food. Food slows absorption without decreasing the quantity absorbed",
                "Dosage form":"tablet 2.5mg",
                "Marketed preparation":"sold under the brand name Femara",
                "Alternatives":"tamoxifen, anastrozole and exemestane."
            },
            "Paclitaxel": {
                "Drug Name": "Paclitaxel",
                "Receptor": "toll-like receptor 4 (TLR4).",
                "LogP Value": "3.96.",
                "Chemical Formula":"C47H51NO14",
                "Half Life":"When a 24 hour infusion of 135 mg/m^2 is given to ovarian cancer patients, the elimination half=life is 52.7 hours",
                "Adverse Effects":"Tingling, Joint pain, Bruising and bleeding, Diarrhea, Dizziness, Hair loss, Mouth sores, Anxiety, Fast heartbeat, Nausea, Feeling sick, High blood pressure, Itching, Low blood pressure, Painful or difficult urination, Pale skin, Melena, Breathlessness, Nail changes, Sore mouth, Blurred or double vision, Changes in liver function, Chest pain, Chills",
                "Food Interactions":"Avoid echinacea. Co-administration may decrease the effectiveness of immunosuppressants, and echinacea may induce CYP3A4 increasing paclitaxel metabolism.Exercise caution with grapefruit products. Grapefruit inhibits CYP3A4 metabolism, which may increase the serum concentration of paclitaxel.Exercise caution with St. John's Wort. This herb induces the CYP3A4 metabolism of paclitaxel and may reduce its serum concentration.",
                "Dosage form": "injectable solution- 6mg/mL",
                "Marketed Preparation": "Taxol",
                "Alternatives": "Docetaxel and nab-paclitaxel"
            },
            "Lapatinib": {
                "Drug Name": "Lapatinib",
                "Receptor": "Lapatinib is an oral, small-molecule, reversible inhibitor of both epidermal growth factor receptor (EGFR) and human epidermal growth factor receptor-2 (HER2) tyrosine kinases..",
                "LogP Value": "4.64.",
                "Chemical Formula":"C29H26ClFN4O4S",
                "Half Life":"Single-dose terminal half life: 14.2 hours Effective multiple-dose half life: 24 hours",
                "Adverse Effects":"avoid if having blistering, peeling, or loosening of the skin, red skin lesions, severe acne or skin rash, sores or ulcers on the skin, or fever or chills while you are using this medicine. Serious skin reactions",
                "Food Interactions":"Avoid grapefruit products. Grapefruit may reduce the CYP3A4 metabolism of lapatinib, increasing its serum levels.  Take separate from meals. Take lapatinib at least 1 hour before or after eating, as lapatinib bioavailability is elevated by food.",
                "Dosage Form": "tablet 250mg",
                "Marketed Preparation": "Tykerb and Tyverb marketed by Novartis",
                "Alternatives": "Anastrozole, Tamoxifen, Letrozole, Arimidex. Exemestane, Palbociclib"
            },
            "Capecitabine": {
                "Drug Name": "Capecitabine",
                "Receptor": "hormone receptor-positive relative to hormone receptor-negative metastatic breast cancer.",
                "LogP Value": "0.0338.",
                "Chemical Formula":"C15H22FN3O6",
                "Half Life":"0.4 h, and in man 0.5 h.",
                "Adverse Effects":"Abdominal pain, Constipation, Diarrhoea, Dizziness, Headache, Vomiting, Bleeding, Mouth ulcer, Trouble sleeping, Hair loss, Back pain, Bloody nose, Blurred vision, Cold, Confusion, Conjunctivitis, Cough producing mucus, Anorexia, Dehydration, Skin rash, Taste changes, Weakness, Blood in the urine or stools, Bone pain",
                "Food Interactions":"Take at the same time every day. Take XELODA 2 times a day at the same time each day, about 12 hours apart. Take with food. Take XELODA within 30 minutes after finishing a meal. Take with plain water. Swallow XELODA tablets whole with water. Do not chew, cut, or crush XELODA tablets",
                "Dosage Form": "tablet 150mg 500mg",
                "Marketed Preparation": "Capecitabine, sold under the brand name Xeloda ",
                "Alternatives": "Ibrance (palbociclib)	Letrozole"
            },
            "Neratinib": {
                "Drug Name": "Neratinib",
                "Receptor": "dual inhibitor of the tyrosine kinase receptors, erbB1 (EGFR) and erbB2 (HER2).",
                "LogP Value": "5.36.",
                "Chemical Formula":"C30H29Cl1N6O3",
                "Half Life":"The mean half life of elimination ranges from 7-17 h following a single dose [FDA Label]. The mean plasma half life during multiple doses is 14.6 h for neratinib, 21.6 h for M3, 13.8 h for M6, and 10.4 h for M7",
                "Adverse Effects":"Nausea, vomiting, mouth sores/pain, stomach/abdominal pain, loss of appetite, weight loss, tiredness, dry skin, nail changes, or muscle spasms",
                "Food Interactions":"Avoid grapefruit products. Grapefruit inhibits CYP3A metabolism, which may increase the serum concentration of neratinib. Exercise caution with St. John's Wort. This herb induces CYP3A metabolism and may reduce serum levels of neratinib. Take at the same time every day. Take separate from antacids. Take antacids at least 3 hours before or after neratinib. Take with food",
                "Dosage Form": "tablet-40mg (equivalent to 48.31mg neratinib       maleate",
                "Marketed Preparation": "40 mg neratinib (equivalent to 48.31 mg of neratinib maleate). Film-coated, red, oval shaped and debossed with 'W104' on one side and plain on the other side.",
                "Alternatives": "Femara. Herceptin. Paclitaxel. Soltamox. Epirubicin"
                
            },
            "Cyclophosphamide": {
                "Drug Name": "Cyclophosphamide",
                "Receptor": ":  cytochrome P450 isoforms, CYP2A6, 2B6, 3A4, 3A5, 2C9, 2C18, and 2C19.",
                "LogP Value": "0.097.",
                "Chemical Formula":"C7H15Cl2N2O2P",
                "Half Life":"3 to 12 hours",
                "Adverse Effects":"Nausea, Loss of appetite, Hair loss, Nail changes, Shortness of breath, Diarrhoea, Mouth sores, Bleeding, Frequent urination, Haematuria, Chills, Fast heartbeat, Abdominal pain, Irritability and restlessness, Fatigue, Urinary tract and renal toxicity, Breathlessness and looking pale, Heart disease, Infection, Joint pain, Liver disease, Low back pain, Lung disease, Missing menstrual periods",
                "Food Interactions":"Avoid grapefruit and grapefruit juice for 48 hours before and on day of your cyclophosphamide dose as it may interact with cyclophosphamide",
                "Dosage Form": "powder for injection 500mg; 1g; 2g Tablet 25mg 50mg",
                "Marketed Preparation": "Cyclophosphamide was initially commercially available as the monohydrate, in a parenteral dosage pre-mix consisting of a sterile, packaged, dry-powder admixture of the drug and sodium chloride",
                "Alternatives": "Ibrance (palbociclib)	Kisqali (ribociclib)"
            },
            "Palbociclib": {
                "Drug Name": "Palbociclib",
                "Receptor": ": Human epidermal growth factor receptor type 2 (HER2)-negative and hormone receptor(HR)-positive tumours .",
                "LogP Value": "2.12.",
                "Chemical Formula":"C24H29N7O2",
                "Half Life":"29 hours",
                "Adverse Effects":"allergic reactions like skin rash, itching or hives, swelling of the face, lips, or tongue. breathing problems. cough.",
                "Food Interactions":"Avoid grapefruit products. Avoid St. John's Wort. Take with food.",
                "Dosage Form": "capsule 75mg 100mg 125mg   tablet 75mg 100mg 125mg",
                "Marketed Preparation": "IBRANCE 75 mg hard capsules",
                "Alternatives": "Letrozole, Intravenous powder for injection"
            },
            "Carboplatin": {
                "Drug Name": "Carboplatin",
                "Receptor": "tyrosine kinase receptor.",
                "LogP Value": "0.04.",
                "Chemical Formula":"C6H12N2O4Pt",
                "Half Life":"The distribution half life of carboplatin is 1.1-2 hours, and the elimination half life was2.6-5.9 hours",
                "Adverse Effects":"Constipation, Hair loss, Infection, Bleeding, Kidney changes, Paresthesia, Hearing changes, Vomiting, Weakness, Allergic reactions, Diarrhoea, Injection site reactions, Mouth sores, Pain, Breathlessness, Fatigue, Feeling or being sick, Loss of appetite, Rash, Tummy pain, Blood in urine or stools, Blurred vision",
                "Food Interactions":"Avoid echinacea. Co-administration may decrease effectiveness of immunosuppressants.",
                "Dosage Form": "lyophilized powder for reconstitution 150mg  injectable solution 10mg/mL (in vials of 50, 150, 450, and 600 mg)",
                "Marketed Preparation": "sterile, pyrogen-free, 10 mg/mL aqueous solution of carboplatin, USP",
                "Alternatives": "Fluorouracil	Doxorubicin"
            },
            "Abemaciclib": {
                "Drug Name": "Abemaciclib",
                "Receptor": "Hormone receptor positive (HR+).",
                "LogP Value": "4.42.",
                "Chemical Formula":"C27H32F2N8",
                "Half Life":"18.3 hours (72% CV)",
                "Adverse Effects":"pain or tenderness in the upper stomach, pale stools, dark urine, loss of appetite, nausea, vomiting, or yellow eyes or skin.",
                "Food Interactions":"Avoid grapefruit products. Grapefruit inhibits CYP3A metabolism, which may increase the serum concentration of abemaciclib. Avoid St. John's Wort. This herb induces CYP3A metabolism and may reduce serum levels of abemaciclib.Take at the same time every day. Take with or without food",
                "Dosage Form": "tablet 50mg 100mg 150mg 200mg",
                "Marketed Preparation": "VERZENIO",
                "Alternatives": "Ibrance(palbociclib)"
            },
            "Evista": {
                "Drug Name": "Evista",
                "Receptor": "selective estrogen receptor modulator with an estrogen-agonistic effect on bone receptors.",
                "LogP Value": "5.45.",
                "Chemical Formula":"C28H27NO4S",
                "Half Life":"27 to 32 hours",
                "Adverse Effects":"hot flashes, flu-like symptoms, muscle spasms, arthralgia, and infection",
                "Food Interactions":"Avoid excessive or chronic alcohol consumption. Excessive and chronic alcohol consumption may be associated with vitamin D deficiency. Take with or without food. The absorption is unaffected by food",
                "Dosage Form": "tablet 60mg",
                "Marketed Preparation": "Evista tablet ",
                "Alternatives": "Alendronate	Fosamax (alendronate)"
            },
            "Pertuzumab": {
                "Drug Name": "Pertuzumab",
                "Receptor": "2 protein (HER2).",
                "LogP Value": "0.264.",
                "Chemical Formula":"C17H27NO2",
                "Half Life":"18 days based on a population pharmacokinetic analysis",
                "Adverse Effects":"Heart problems, including those without symptoms (such as reduced heart function) and those with symptoms (such as congestive heart failure). Receiving PERJETA during pregnancy can result in the death of an unborn baby and birth defects.",
                "Food Interactions":"no interaction.",
                "Dosage Form": "injectable solution •	30mg/mL(420mg/14 mL)",
                "Marketed Preparation": " Perjeta",
                "Alternatives": ": i. Verzenio (abemaciclib)  ii. Ibrance(palbociclib) "
            },
            "Epirubicin": {
                "Drug Name": "Epirubicin",
                "Receptor": "anthracycline topoisomerase II inhibitor.",
                "LogP Value": "0.53.",
                "Chemical Formula":"C27H29NO11",
                "Half Life":"30 to 40 hours",
                "Adverse Effects":"Hair loss, Diarrhea, Mouth sores and ulcers, Nausea, Changes to nails, Discoloured urine, Fatigue, Bleeding, Missed menstrual periods, Skin changes, Stomach pain, Cardiac toxicity, Chills, Heart arrhythmia, Feeling of warmth, Swelling, Tissue hypoxia, Cough, Chest pain, High fever, Hives, Hot flashes, Skin rash, Lower back or side pain",
                "Food Interactions":"Drink plenty of fluids. Increased fluid intake increases urine output and the excretion of uric acid. ",
                "Dosage Form": "injectable solution-2mg/mL as single dose vial containing 50mg/25mL or 200mg/100mL",
                "Marketed Preparation": "Each ml contains 2 mg epirubicin hydrochloride",
                "Alternatives": "Tamoxifen	Letrozole"
            },
            "Trastuzumab": {
                "Drug Name": "Trastuzumab",
                "Receptor": "HER2 receptor positive.",
                "LogP Value": "0.35.",
                "Chemical Formula":"C6448H9948N1720O2012S44 · 2 Oligosaccharid-Reste · (C47H61ClN4O13S)n (n = ca. 3,5)",
                "Half Life":"The terminal half-life is approximately 28 days, but may decrease with lower doses - at the 10mg and 500mg doses, half-lives averaged approximately 1.7 and 12 days, respectively",
                "Adverse Effects":"Headache. Chills. Gastrointestinal symptoms (nausea and vomiting; abdominal pain, diarrhea) Cough. Back pain. Upper respiratory symptoms (rhinitis, pharyngitis) Weakness and fatigue",
                "Food Interactions":"The terminal half-life is approximately 28 days, but may decrease with lower doses - at the 10mg and 500mg doses, half-lives averaged approximately 1.7 and 12 days, respectively",
                "Dosage Form": "injection, powder for reconstitution •	150mg/single-dose vial (Herceptin, Hercessi, Ontruzant) •	420mg/multidose vial (Herceptin, Ogivri, Herzuma, Trazimera, Kanjinti, Ontruzant)",
                "Marketed Preparation": "brand name Herceptin",
                "Alternatives": "Verzenio (abemaciclib)	Ibrance (palbociclib)"
            },
            "Fluorouracil": {
                "Drug Name": "Fluorouracil",
                "Receptor": "Epidermal Growth Factor Receptor .",
                "LogP Value": "-0.66.",
                "Chemical Formula":"C4H3FN2O2",
                "Half Life":"8 to 20 minutes.",
                "Adverse Effects":"Altered mental status, confusion, disorientation, intense feelings of joy, difficulty walking and balancing, coma. Allergic reaction which may cause rash, low blood pressure, wheezing, shortness of breath, swelling of the face or throat. Blood clot which may cause swelling, pain, or shortness of breath.",
                "Food Interactions":"Products containing folic acid may increase the effects of fluorouracil. You may be more likely to develop serious side effects such as anaemia, bleeding problems, infections, and nerve damage when these medications are used together.",
                "Dosage Form": "injectable solution •	50mg/mL (500mg/10mL single-dose vial)",
                "Marketed Preparation": "sold under the brand name Adrucil among others, is a cytotoxic chemotherapy medication used to treat cancer.",
                "Alternatives": "Carac, Tolak, Fluoroplex, Aminolevulinic acid topical, Klisyri, Ameluz"
            },
            "Clomiphene": {
                "Drug Name": "Clomiphene",
                "Receptor": "selective estrogen receptor modulator.",
                "LogP Value": "  4",
                "Chemical Formula":"C26H28ClNO",
                "Half Life":"5 to 7 days.",
                "Adverse Effects":"Ovarian hyperstimulation syndrome—stomach or pelvic pain, bloating, nausea, vomiting, diarrhea, weight gain.",
                "Food Interactions":"•	Take with or without food. The absorption is unaffected by food.",
                "Dosage form":"Tablet 50mg.",
                "Marketed preparation":"Clomid 50",
                "Alternatives":"Tamoxifen, glumetza.."
            } ,
            "Acarbose": {
                "Drug Name": "Acarbose",
                "Receptor": "competitively and reversibly inhibits both pancreatic alpha-amylase and membrane-bound alpha-glucosidases - of the alpha-glucosidases, inhibitory        potency appears to follow a rank order of glucoamylase > sucrase > maltase > isomaltase.",
                "LogP Value": "-3.29",
                "Chemical Formula":"C25H43NO18 ",
                "Half Life":"2 hours",
                "Adverse Effects":"signs of liver problems (such as nausea/vomiting that doesn't stop, loss of appetite, stomach/abdominal pain, yellowing eyes/skin, dark urine).",
                "Food Interactions":"Take with food. Each dose should be taken with the first bite of a main meal.	",
                "Dosage form":"Tablet 25, 50, 100 mg",
                "Marketed preparation":"Glucobay, Precose",
                "Alternatives":"GlucoGon, GlucoPure"
            },
            "Eflornithine": {
                "Drug Name": "Eflornithine",
                "Receptor": "Irreversible inhibitor of the enzyme ornithine decarboxylase .",
                "LogP Value": "-3.1 to -2.9",
                "Chemical Formula":"C6H12F2N2O2",
                "Half Life":"3.5 hours.",
                "Adverse Effects":": stinging, burning, or tingling of the skin. redness of the skin..",
                "Food Interactions":"Take with or without food	",
                "Dosage form":"Cream 4170mg/30g Tablet 250mg",
                "Marketed preparation":"Florexa (cream)  Iwilfin , Vaniqa",
                "Alternatives":"Vaniqa."  
            },
            "Desogestrel": {
                "Drug Name": "Desogestrel",
                "Receptor": ": Binding selectively to the progesterone receptor and generating low androgenic activity.",
                "LogP Value": "3.5 to 4.0",
                "Chemical Formula":"C22H30O",
                "Half Life":"30 hours",
                "Adverse Effects":"Breast abnormalities; depressed mood; headache; libido decreased; menstrual cycle irregularities; mood altered; nausea; skin reactions",
                "Food Interactions":"Moderate Food Interaction",
                "Dosage form":"Tablet (0.075mg)",
                "Marketed preparation":"Alenvona, Apri, Azalia, Azurette, Bekyree",
                "Alternatives":"Nexplanone, NuvaRing, Sprintec." 
            },
            "Metformin": {
                "Drug Name": "Metformin",
                "Receptor": "AMP-activated protein kinase",
                "LogP Value": "-1.43.",
                "Chemical Formula":"C4H11N5",
                "Half Life":"6.2 hours in the plasma and in the blood is approximately 17.6 hours.",
                "Adverse Effects":":  lactic acidosis, allergies, hypoglycemia, vitamin B12 deficiency, altered taste, and gastrointestinal intolerance.",
                "Food Interactions":"Avoid alcohol. Take with food. Food reduces irritation.	",
                "Dosage form":"Tablet 500mg, 850mg, 1000mg",
                "Marketed preparation":"Bci Metformin. Fortamet, Glucophage",
                "Alternatives":"Berbaprime"   
            },
            "Finasteride": {
                "Drug Name": "Finasteride",
                "Receptor": "competitive and specific inhibitor of Type II 5α-reductase, a nuclear-bound steroid intracellular enzyme primarily located in the prostatic stromal cell that converts the androgen testosterone into the more active metabolite",
                "LogP Value": "3.1",
                "Chemical Formula":"C23H36N2O2",
                "Half Life":"3 to 16 hours",
                "Adverse Effects":"Chills, cold sweats, Confusion, dizziness, faintness, or lightheadedness when getting up suddenly from a lying or sitting position",
                "Food Interactions":"Take with or without food. The absorption is unaffected by food.",
                "Dosage form":"Tablet (1, 5 mg)",
                "Marketed preparation":"Act Finasteride, M-finasteride",
                "Alternatives":"Minoxidil, Dutasteride"   
            },
            "Drospirenone": {
                "Drug Name": "Drospirenone",
                "Receptor": "Suppress the release of follicle stimulating hormone (FSH) and luteinizing hormone (LH), preventing ovulation.",
                "LogP Value": "3.7",
                "Chemical Formula":"C24H30O3",
                "Half Life":"30 hours",
                "Adverse Effects":"Allergic reactions—skin rash, itching, hives, swelling of the face, lips, tongue, or throat",
                "Food Interactions":"Avoid St. John's Wort. Take at the same time every day. Take with or without food.	",
                "Dosage form":"Tablet (4 mg)",
                "Marketed preparation":"Slynd",
                "Alternatives":"Nexplanone, NuvaRing, Sprintec"   
            },
            "Flutamide": {
                "Drug Name": "Flutamide",
                "Receptor": "potent inhibitor of testosterone-stimulated prostatic DNA synthesis.",
                "LogP Value": "3.01",
                "Chemical Formula":"C11H11F3N2O3 ",
                "Half Life":"6 hours",
                "Adverse Effects":"Hot flashes, loss of sexual interest/ability, diarrhea, nausea, vomiting, and enlargement of male breasts",
                "Food Interactions":"Take with or without food. The absorption is unaffected by food.",
                "Dosage form":"Tablet , Capsule (125 , 250 mg)",
                "Marketed preparation":"Euflex , Eulexin , Flutamide",
                "Alternatives":"Zytiga, Lupron Depot, Xtandi, Erleada"   
            },
            "Liraglutide": {
                "Drug Name": "Liraglutide",
                "Receptor": "Agonist of the glucagon-like peptide-1 receptor which is coupled to adenylate cyclase. Slows gastric emptying to increase control of blood sugar",
                "LogP Value": "-2.8 to -3.1",
                "Chemical Formula":"C172H265N43O51",
                "Half Life":"13 hours",
                "Adverse Effects":"nausea, diarrhea, vomiting, decreased appetite, indigestion, and constipation",
                "Food Interactions":"Take with or without food.	",
                "Dosage form":"Injection , Solution (6mg/ml)",
                "Marketed preparation":"Victoza, Saxenda",
                "Alternatives":"Topiramate, Semaglutide, Tirzepatide" 
            },
            "Letrozole": {
                "Drug Name": "Letrozole",
                "Receptor": "Blocks the active site, and therefore the electron transfer chain of CYP19A1. This competitive inhibition prevents the conversion of androgens to estrogen",
                "LogP Value": "2.92",
                "Chemical Formula":"C17H11N5",
                "Half Life":"42h in healthy volunteers",
                "Adverse Effects":"hot flushes, difficulty sleeping, tiredness and low mood",
                "Food Interactions":"Take with or without food. Food slows absorption without decreasing the quantity absorbed.",
                "Dosage form":"Tablet 2.5 mg",
                "Marketed preparation":"Co letrozole, Femara, Nra letrozole",
                "Alternatives":"Fempro, Stimufol, Letsi, Letoval"   
            },
            "Rosiglitazone": {
                "Drug Name": "Rosiglitazone",
                "Receptor": "Agonist at peroxisome proliferator activated receptors",
                "LogP Value": "3.7",
                "Chemical Formula":" C18H19N3O3S",
                "Half Life":"3 to 4 Hours.",
                "Adverse Effects":"edema, hypertension, heart failure/congestive heart failure, myocardial ischemia, diarrhea, upper respiratory tract infection. .",
                "Food Interactions":"Take with or without food.	",
                "Dosage form":"Tablet 2, 4 , 8 mg",
                "Marketed preparation":"Avandia",
                "Alternatives":"Ozempic, Rybelsus , Semaglutide."   
            },
            "Sibutramine": {
                "Drug Name": "Sibutramine",
                "Receptor": "Inhibition of norepinephrine (NE), serotonin (5-hydroxytryptamine, 5-HT), and to a lesser extent, dopamine reuptake at the neuronal synapse. ",
                "LogP Value": ": 5.3",
                "Chemical Formula":"C17H26ClN",
                "Half Life":"1.1 hours",
                "Adverse Effects":" Dry mouth, headache, insomnia, asthenia, obstipation and in some cases amnesia ",
                "Food Interactions":"Using sibutramine with alcohol can increase the risk of cardiovascular side effects such as increased heart rate, chest pain, or blood pressure changes.	",
                "Dosage form":"Capsule (5, 10, 15 mg)",
                "Marketed preparation":"Meridia",
                "Alternatives":"Topiramate, Semaglutide, Adipex- P."   
            },
            "Drospirenone": {
                "Drug Name": "Drospirenone",
                "Receptor": "Suppress the release of follicle stimulating hormone (FSH) and luteinizing hormone (LH), preventing ovulation.",
                "LogP Value": "3.7",
                "Chemical Formula":"C24H30O3",
                "Half Life":"30 hours",
                "Adverse Effects":"Allergic reactions—skin rash, itching, hives, swelling of the face, lips, tongue, or throat.",
                "Food Interactions":": Avoid St. John's Wort. Take at the same time every day. Take with or without food.	",
                "Dosage form":"Tablet (4 mg)",
                "Marketed preparation":"Slynd",
                "Alternatives":"Nexplanone, NuvaRing, Sprintec."   
            },
            "Pioglitazone": {
                "Drug Name": "Pioglitazone",
                "Receptor": "Activation of PPARγ increases the transcription of insulin-responsive genes involved in the control of glucose and lipid production, transport, and utilization.",
                "LogP Value": "1.5 to 2.1",
                "Chemical Formula":"C19H20N2O3S",
                "Half Life":"3-7 hours",
                "Adverse Effects":"weight gain, pedal edema, bone loss and precipitation of congestive heart failure in at-risk individuals, without any increase in CVD/all-cause mortality",
                "Food Interactions":" Take with or without food. Food delays drug absorption, but not to a clinically significant extent.",
                "Dosage form":"Tablet (15, 30, 45 mg)",
                "Marketed preparation":"Act Pioglitazone, Actos",
                "Alternatives":"Ozempic, Rybelsus, Semaglutide"  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Ethinylestradiol Plus Levonorgestrel",
                "Receptor": "binds to progesterone and androgen receptors and slows the release of gonadotropin-releasing hormone (GnRH) from the hypothalamus",
                "LogP Value": "3.2 to 3.7",
                "Chemical Formula":"C21H28O2",
                "Half Life":"0.75 mg dose of 1.5 mg of levonorgestrel ranges between 20-60 hours",
                "Adverse Effects":"alterations of menstrual bleeding patterns, nausea, abdominal/pelvic pain, headache/migraine, dizziness, fatigue, amenorrhea, ovarian cysts, genital discharge, acne/seborrhea, breast tenderness, and vulvovaginitis",
                "Food Interactions":"Grapefruit juice may increase the blood levels of certain medications such as levonorgestrel",
                "Dosage form":"Intrauterine device",
                "Marketed preparation":"Jaydess, Kyleena, Liletta ",
                "Alternatives":"Take Action, My Way, Option 2, Preventeza, AfterPill, My Choice, Aftera, and EContra"  
            },
            "Levothyroxine": {
                "Drug Name": "Levothyroxine",
                "Receptor": "Levothyroxine primarily binds to and activates the thyroid hormone receptors, including thyroid hormone receptor alpha (TRα) and thyroid hormone receptor beta (TRβ) ",
                "LogP Value": "3.73",
                "Chemical Formula":"C15H11I4NO4",
                "Half Life":"7 days",
                "Adverse Effects":"Insomnia, Headache, Increased heart rate, Nervousness or anxiety, Shakiness or tremors, Sweating, Heat intolerance, Weight loss, Diarrhea or vomiting.",
                "Food Interactions":"Levothyroxine absorption can be significantly affected by food. It's generally recommended to take levothyroxine on an empty stomach, preferably in the morning, at least 30 minutes to 1 hour before breakfast or consuming any food, beverages, or other medications.	",
                "Dosage form":"tablet 30 mg, 25mcg,50mcg",
                "Marketed preparation":"LEVOAMI 100",
                "Alternatives":"Levoxyl. Nature-Throid. Cytomel. Tirosint. Liothyronine, Euthyrox"  
            },
            "methimazole  ": {
                "Drug Name": "methimazole",
                "Receptor": "Methimazole primarily binds to and inhibits the enzyme thyroid peroxidase (TPO)",
                "LogP Value": "0.77",
                "Chemical Formula":"C4H6N2S",
                "Half Life":"4 to 6 hours",
                "Adverse Effects":"Nausea and vomiting, Skin rash or itching, Headache, Muscle or joint pain, Hair loss, Changes in taste, Drowsiness or fatigue, Swelling of the ankles or feet, Changes in menstrual periods, Liver problems (rare)",
                "Food Interactions":"methimazole with food to reduce gastrointestinal upset. Additionally, avoiding excessive amounts of foods high in iodine, such as seaweed and iodized salt, may be advisable, as they could potentially interfere with the effectiveness of methimazole in treating hyperthyroidism",
                "Dosage form":"5mg tablet , 10 mg tablet",
                "Marketed preparation":"Methimez® 5 Methimazole Tablets USP 5mg , MTMAZOLE - 5 TAB",
                "Alternatives":"Potassium iodide, SSKI, ThyroShield, Iodine / potassium iodide., Sodium iodide-i-131., Hicon." 
            }, 
            "liothyronine  ": {
                "Drug Name": "liothyronine",
                "Receptor": "Liothyronine (T3) primarily binds to thyroid hormone receptors (TRs) located in the nucleus of target cells.",
                "LogP Value": "2.53",
                "Chemical Formula":"C15H12I3NO4",
                "Half Life":"1 to 2 days",
                "Adverse Effects":"Chest pain or angina, Irregular heartbeat (arrhythmia), Hypertension (high blood pressure), Allergic reactions (such as rash, itching, or swelling), Worsening of heart conditions or angina in patients with pre-existing heart disease",
                "Food Interactions":"There aren't any significant food interactions with liothyronine. However, it's generally recommended to take liothyronine on an empty stomach, preferably in the morning, at least 30 minutes to 1 hour before breakfast or consuming any food",
                "Dosage form":"5mcg tablet, 50mcg ",
                "Marketed preparation":"SHYTOMEL Liothyronine Sodium Tablets USP, SHYTOMEL DUO 47.       Liothyronine Sodium Tablets, USP 5 mcg",
                "Alternatives":"Levothyroxine, Synthroid"  
            },
            "propylthiouracil ": {
                "Drug Name": "propylthiouracil ",
                "Receptor": "Methimazole primarily binds to and inhibits the enzyme thyroid peroxidase (TPO).",
                "LogP Value": "0.77",
                "Chemical Formula":"C4H6N2S",
                "Half Life":"4 to 6 hours",
                "Adverse Effects":"Nausea and vomiting, Skin rash or itching, Headache, Muscle or joint pain, Hair loss, Changes in taste, Drowsiness or fatigue, Swelling of the ankles or feet, Changes in menstrual periods, Liver problems (rare)",
                "Food Interactions":"There aren't any significant food interactions with propylthiouracil (PTU). However, it's generally recommended to take PTU on an empty stomach, either 1 hour before or 2 hours after meals, to ensure optimal absorption",
                "Dosage form":"50 mg ",
                "Marketed preparation":"Propylthiouracil Tablets IP, Propylthiouracil 50mg, PROPYL",
                "Alternatives":"Methimazole, Tapazole"  
            },
            "Tirosint ": {
                "Drug Name": "Tirosint",
                "Receptor": "binds to thyroid hormone receptors in various tissues throughout the body",
                "LogP Value": "0.75",
                "Chemical Formula":"C15H10I4N NaO4",
                "Half Life":"7 days",
                "Adverse Effects":"Allergic reactions such as rash, itching, swelling of the face, tongue, or throat, severe dizziness, or trouble breathing",
                "Food Interactions":"Food can interact with Tirosint absorption in the digestive system. Tirosint is usually taken on an empty stomach, preferably in the morning at least 30 minutes to 1 hour before breakfast, with a full glass of water	",
                "Dosage form":"13 mcg capsule, 100 microgram/ml solution",
                "Marketed preparation":"TIROSINT ®(levothyroxine sodium) capsules 50 mcg , TIROSINT® - SOL",
                "Alternatives":"Levothyroxine	, Synthroid (levothyroxine)"  
            },
            "Vandetanib": {
                "Drug Name": "Vandetanib",
                "Receptor": "Vandetanib primarily inhibits several receptor tyrosine kinases (RTKs), including: Epidermal growth factor receptor (EGFR), Vascular endothelial growth factor receptor (VEGFR), Ret proto-oncogene (RET), By inhibiting these receptors",
                "LogP Value": "3.7",
                "Chemical Formula":"C22H24BrFN4O2",
                "Half Life":"19 days",
                "Adverse Effects":"Diarrhea, Rash, Hypertension (high blood pressure), Nausea and vomiting, Fatigue, Decreased appetite, Abdominal pain, Headache, QT interval prolongation (a heart rhythm abnormality), Hand-foot syndrome (pain, redness, swelling, and/or peeling of the skin on the palms of the hands and soles of the feet)",
                "Food Interactions":"Food can affect the absorption of vandetanib. It is typically recommended to take vandetanib at least 1 hour before or 2 hours after a meal, as food can reduce the absorption of the medication.",
                "Dosage form":"Tablet 300mg",
                "Marketed preparation":"LUCIVAND 300 , Caprelsa",
                "Alternatives":"Armour Thyroid, Tafinlar"  
            },
            "Pazopanib": {
                "Drug Name": "Pazopanib",
                "Receptor": "Pazopanib primarily binds to and inhibits multiple receptor tyrosine kinases (RTKs), including: Vascular endothelial growth factor receptors (VEGFRs): Pazopanib inhibits VEGFR-1, VEGFR-2, and VEGFR-3, which are involved in angiogenesis, the process of forming new blood vessels. Platelet-derived growth factor receptors (PDGFRs): Pazopanib inhibits PDGFR-α and PDGFR-β, which are involved in cell growth and division",
                "LogP Value": "3.17",
                "Chemical Formula":"C21H23N7O2",
                "Half Life":"30 hours",
                "Adverse Effects":"Fatigue, Diarrhea, Nausea and vomiting, Hypertension (high blood pressure), Decreased appetite, Hair color changes (lightening), Abdominal pain, Changes in taste, Headache, Skin rash or dryness",
                "Food Interactions":"Food can affect the absorption of pazopanib. It is generally recommended to take pazopanib on an empty stomach, at least one hour before or two hours after eating.",
                "Dosage form":"Tablet 200 mg , 400 mg",
                "Marketed preparation":"PAZOKAST 400 mg, PAZOCAM 400mg , Votrient 200 mg",
                "Alternatives":"Sutent (sunitinib), Votrient (pazopanib)"  
            },
            "Liotrex ": {
                "Drug Name": "Liotrex ",
                "Receptor": "does not directly bind to specific receptors like traditional drugs. Instead, these thyroid hormones enter cells and interact with nuclear receptors known as thyroid hormone receptors (THR)",
                "LogP Value": "3.0 to 3.5",
                "Chemical Formula":"C15H11I4NO4",
                "Half Life":"1 to 2 days",
                "Adverse Effects":"Chest pain or angina, Cardiac arrhythmias, Excessive thyroid hormone levels (hyperthyroidism), Hypothyroidism (if the dose is too low), Allergic reactions",
                "Food Interactions":"There are no significant food interactions reported specifically for liotrix. Take liotrix on an empty stomach, preferably in the morning, at least 30 to 60 minutes before breakfast. This helps to ensure optimal absorption of the medication",
                "Dosage form":"Tablet	100.000 mcg, Tablet	150 mcg",
                "Marketed preparation":"Thyrolar, Liotrix Tablets USP, ",
                "Alternatives":"Levothyroxine, Synthroid"  
            },
            "Carbimazole ": {
                "Drug Name": "Carbimazole ",
                "Receptor": "Carbimazole primarily binds to and inhibits the activity of the enzyme thyroid peroxidase (TPO) in the thyroid gland",
                "LogP Value": "0.82",
                "Chemical Formula":"C7H10N2O2S",
                "Half Life":"6 to 8 hours",
                "Adverse Effects":"Agranulocytosis (a severe decrease in white blood cells), Liver toxicity, Allergic reactions, such as swelling of the face, lips, or tongue, and difficulty breathing",
                "Food Interactions":"Carbimazole can be taken with or without food. However, it’s generally recommended to take it with meals to help minimize any potential gastrointestinal discomfort that may occur",
                "Dosage form":"tablet 5mg , 10mg,15mg, 20mg",
                "Marketed preparation":"Neo-mercazole 10, CARKOZOM -5, CARBIDAX, Thyrocab",
                "Alternatives":"Propylthiouracil, Methimazole "  
            },
            "Triiodothyronine": {
                "Drug Name": "Triiodothyronine",
                "Receptor": "Triiodothyronine (T3) primarily binds to nuclear thyroid hormone receptors",
                "LogP Value": "2.11",
                "Chemical Formula":"C15H12I3NO4",
                "Half Life":"1 to 2 days",
                "Adverse Effects":"Palpitations or rapid heartbeat: Some individuals may experience palpitations or a sensation of their heart racing. Tremors or jitteriness: Experiencing tremors or feelings of jitteriness is not uncommon, especially at higher doses. Increased appetite or weight loss: T3 supplementation can sometimes lead to increased appetite or weight loss",
                "Food Interactions":"can be affected by certain foods and dietary factors	",
                "Dosage form":"Tablet : 125mcg , 100mcg, 20 mg ",
                "Marketed preparation":"THYROX-25,T3 Cytomel, THYROXINE SODIUM TABLETS I.P. 125 mcg , ELTROXIN",
                "Alternatives":"Armour Thyroid, Cytomel, Thyrolar, Synthroid"  
            },
            "Dexamethasone": {
                "Drug Name": "Dexamethasone",
                "Receptor": " Dexamethasone primarily binds to and activates the glucocorticoid receptor (GR), which is a nuclear receptor",
                "LogP Value": "1.57",
                "Chemical Formula":": C22H29FO5",
                "Half Life":"3 to 4 hr",
                "Adverse Effects":"Increased appetite and weight gain. Insomnia or changes in sleep patterns. Mood changes, such as irritability or agitation. Fluid retention, leading to swelling or edema. Elevated blood sugar levels, which can worsen diabetes or predispose individuals to develop diabetes. Increased susceptibility to infections due to suppression of the immune system. Gastrointestinal issues such as stomach irritation or ulcers. Muscle weakness or wasting, Skin problems such as acne or thinning of the skin, Osteoporosis or bone density loss with long-term use",
                "Food Interactions":"Dexamethasone can interact with certain foods, particularly those high in sodium or potassium. Consuming excessive amounts of sodium can lead to fluid retention and electrolyte imbalances",
                "Dosage form":"2mg IV or PO q12h Tablet- 0.5mg (generic) 0.75mg (generic) 1mg (generic) 1.5mg (generic) 2mg (generic) 4mg (generic) 6mg (generic) Injectable suspension- 4mg/mL (generic), 10mg/mL (generic)",
                "Marketed preparation":"Decmax 8 mg, Dexamethasone Sodium Phosphate, Dexamethasone Sodium Phosphate Injection USP- 4 mg per mL",
                "Alternatives":"Rinvoq. Triamcinolone topical. Upadacitinib"  
            },
            "Thyroxin ": {
                "Drug Name": "Thyroxin ",
                "Receptor": "Thyroxine (T4) primarily binds to thyroid hormone receptors (TRs) which are found in the nuclei of target cells throughout the body",
                "LogP Value": "0.71",
                "Chemical Formula":"C15H11I4NO4",
                "Half Life":"6 to 7 days",
                "Adverse Effects":"Chest pain, Rapid or irregular heartbeat (palpitations), Excessive sweating, Heat intolerance, Shortness of breath, Muscle weakness, Changes in mood or mental state (such as confusion or depression), Allergic reactions (rash, itching, swelling of the face or throat, difficulty breathing)",
                "Food Interactions":"Thyroxine (levothyroxine) absorption can be affected by certain foods and medications. It's generally recommended to take thyroxine on an empty stomach, preferably in the morning, at least 30 minutes to 1 hour before breakfast or other medications. This ensures optimal absorption	",
                "Dosage form":"Tablets 25 mcg (0.025 mg); 50 mcg (0.05 mg); 75 mcg",
                "Marketed preparation":"Thyroxine Sodium Tablets I.P. 25 mcg L-Thyroid-25. THYROVIB-75 , Thyrodax-37.5",
                "Alternatives":"Levothyroxine , Armour Thyroid, Cytomel, Thyrolar, Synthroid, and Levoxyl"  
            },
            "Sunitinib ": {
                "Drug Name": "Sunitinib ",
                "Receptor": "Sunitinib binds to and inhibits various receptor tyrosine kinases (RTKs), including vascular endothelial growth factor receptors (VEGFRs), platelet-derived growth factor receptors (PDGFRs), stem cell factor receptor (KIT)",
                "LogP Value": "5.7",
                "Chemical Formula":"C22H27FN4O2",
                "Half Life":"40 to 60 hours ",
                "Adverse Effects":"Fatigue, Diarrhea, Nausea and vomiting, Loss of appetite, Hand-foot syndrome (palmar-plantar erythrodysesthesia), Hypertension (high blood pressure), Skin discoloration or rash, Hair color changes, Taste alterations, Bone marrow suppression (leading to decreased blood cell counts)",
                "Food Interactions":"Sunitinib should be taken on an empty stomach, preferably without food, as food, especially a high-fat meal, can significantly decrease its absorption and effectiveness",
                "Dosage form":"25mg capsule. 12.5 mg capsule",
                "Marketed preparation":"SUTEKAST-25, Sunitinib Malate Capsules-50 mg, Sugistran",
                "Alternatives":"Sutent(sunitinib), Votrient(pazopanib) , Inlyta (axitinib)"  
            },
            "Calcitonin  ": {
                "Drug Name": "Calcitonin  ",
                "Receptor": "Calcitonin primarily binds to calcitonin receptors",
                "LogP Value": "-0.3",
                "Chemical Formula":"C145H240N44O48S2",
                "Half Life":"10 min",
                "Adverse Effects":"Nausea, Flushing of the face, Skin rash or itching at the injection site, Headache, Muscle pain or weakness, Joint pain, Decreased appetite, Diarrhea or constipation, Dizzines, Injection site reactions, such as redness, swelling, or pain",
                "Food Interactions":"Calcitonin is typically administered through injection, nasal spray, or rarely as a nasal solution. Since it is not taken orally and does not undergo significant metabolism in the digestive system, there are generally no specific food interactions associated with calcitonin	",
                "Dosage form":"2 mL Multi-Dose Vial, 3.7 ml solution ",
                "Marketed preparation":"BMD RISE, UNICALCIN-100, Kalto100 1.U./ml solution",
                "Alternatives":"Alendronate , Fosamax (alendronate)"  
            },
            "Thyrotropin Alfa  ": {
                "Drug Name": "Thyrotropin Alfa  ",
                "Receptor": " Binds to the TSH receptor on the surface of thyroid cells ",
                "LogP Value": "-2.5",
                "Chemical Formula":"C135H215N41O56S",
                "Half Life":"25 to 10hr",
                "Adverse Effects":"Headache, Nausea, Fatigue, Vomiting, Dizziness, Mild fever, Injection site reactions (such as redness or swelling)",
                "Food Interactions":"no interaction found 	",
                "Dosage form":"injection - 0.9 mg/mL , 0.9 mg/1mL",
                "Marketed preparation":"Thyrogen® thyrotropin alfa for injection.",
                "Alternatives":"Tafinlar, Lexiscan, Aplisol"  
            },
            "Sorafenib ": {
                "Drug Name": "Sorafenib ",
                "Receptor": "Raf kinases (Raf-1 and B-Raf): These kinases are part of the RAF/MEK/ERK signaling pathway, which regulates cell proliferation and survival. Inhibition of Raf kinases by sorafenib prevents downstream signaling and inhibits tumor cell proliferation.",
                "LogP Value": "3.68",
                "Chemical Formula":"C21H16ClF3N4O3",
                "Half Life":"1 to 2 days",
                "Adverse Effects":"Fatigue, Diarrhea, Nausea and vomiting, Rash or skin reactions, Hand-foot skin reaction (palmar-plantar erythrodysesthesia), Hypertension (high blood pressure), Decreased appetite, Abdominal pain, Hair thinning or loss, Changes in taste, Headache, Weight loss",
                "Food Interactions":"Food can affect the absorption of sorafenib. It is generally recommended to take sorafenib on an empty stomach	",
                "Dosage form":"Tablet 200 mg",
                "Marketed preparation":"Soranib , Sorafenib Tablets 200 mg Soranib; Sorafenat , SorafiRel™200 mg",
                "Alternatives":"Nexavar (sorafenib)	; Sutent (sunitinib)"  
            },
            " Halofuginone ": {
                "Drug Name": "Halofuginone ",
                "Receptor": "potent pulmonary vasodilator by activating Kv channels and blocking VDCC and receptor-operated and store-operated Ca2+ channels in PASMCs",
                "LogP Value": " 0.025 ",
                "Chemical Formula":"C16H17BrClN3O3",
                "Half Life":"11.7 hours after intravenous administration and 30.84 hours after single oral administration",
                "Adverse Effects":"nausea, vomiting and hepatotoxicity",
                "Food Interactions":"no interaction with food",
                "Dosage form":"100 µg of halofuginone base / kg body weight (BW)",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Anastrozole ": {
                "Drug Name": "Anastrozole ",
                "Receptor": "Estrogen Receptor",
                "LogP Value": "2.4",
                "Chemical Formula":"C17H19N5",
                "Half Life":"50 hrs",
                "Adverse Effects":"hot flashes, vaginal dryness and musculoskeletal pain",
                "Food Interactions":"avoid rich or spicy food",
                "Dosage form":"Adults—1 milligram (mg) once a day ",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Pirfenidone ": {
                "Drug Name": "Pirfenidone ",
                "Receptor": "Cannabinoid receptor 2 (CB2R) is a receptor predominantly expressed in the immune system",
                "LogP Value": "1.82",
                "Chemical Formula":"C12H11NO",
                "Half Life":"0.33-1 hours",
                "Adverse Effects":"Acid or sour stomach. Pain or tenderness around the eyes and cheekbones. Lack or loss of strength. Increased sensitivity of the skin to sunlight. Body aches or pain. Change in taste. Ear congestion. Heartburn or indigestion.",
                "Food Interactions":"Pirfenidone should be taken with food to help reduce dizziness and gastrointestinal side effects such as diarrhea, nausea, vomiting, and upset stomach. Avoid smoking during treatment, as cigarette smoking can reduce the blood levels and effects of pirfenidone	",
                "Dosage form":"Adults—On Days 1 to 7, 267 milligrams (mg) 3 times a day. On Days 8 to 14, 534 mg 3 times a day. On Day 15 and each day after, 801 mg 3 times a day. ",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Myfembree": {
                "Drug Name": "Myfembree",
                "Receptor": "-Myfembree (relugolix, estradiol, and norethindrone acetate) is a combination of a gonadotropin-releasing hormone (GnRH) receptor antagonist, an estrogen, and a progestin",
                "LogP Value": "≤ 0.0001",
                "Chemical Formula":"C29H27F2N7O5S",
                "Half Life":"25 hours",
                "Adverse Effects":"Hot flashes (flushing), muscle/joint pain, tiredness, constipation, and diarrhea may occur. Reduced sexual interest/ability and weight gain may also occur as a result of lowered testosterone levels. If any of these effects last or get worse, tell your doctor or pharmacist promptly",
                "Food Interactions":"Grapefruit and grapefruit juice should be avoided if an interaction is suspected. Orange juice is not expected to interact with these drugs.	",
                "Dosage form":"tablet- 40mg/1mg/0.5mg",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "acetaminophen ": {
                "Drug Name": "acetaminophen ",
                "Receptor": "COX, anandamide, CB1, TRPV1, opioid, and 5-HT3 receptors. ",
                "LogP Value": "0.25",
                "Chemical Formula":"C8H9NO2",
                "Half Life":"2 hours",
                "Adverse Effects":"–stomach pain (upper right side); Loss of appetite; Tiredness, itching; Dark urine, clay-colored stools; or Jaundice (yellowing of the skin or eyes).",
                "Food Interactions":"food may slow the body absorption of acetaminophen. Coadministration of acetaminophen with pectin delays its absorption a",
                "Dosage form":"-oral capsule (325 mg; 500 mg), oral granule, effervescent (650 mg), oral liquid (160 mg/5 mL; 325 mg/10.15 mL; 500 mg/15 mL; 650 mg/20.3 mL)",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ulipristal Acetate": {
                "Drug Name": "Ulipristal Acetate",
                "Receptor": "-progesterone receptors to produce an anti-progesterone contraceptive effect on the ovary (by suppressing or delaying ovulation) and on the endometrium (by decreasing endometrial thickness)",
                "LogP Value": "4.62",
                "Chemical Formula":"C30H37NO4",
                "Half Life":"32.4 ± 6.3 hours",
                "Adverse Effects":"Headache, nausea, abdominal pain, dysmenorrheal, fatigue, dizziness",
                "Food Interactions":"The tablet may be taken regardless of food intake or time of menstrual cycle.",
                "Dosage form":"30-mg oral tablet as a single-dose, taken after unprotected intercourse as soon as possible (and within 120 hours)",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "mifepristone  ": {
                "Drug Name": "mifepristone  ",
                "Receptor": "glucocorticoid and progesterone receptors",
                "LogP Value": "5.4",
                "Chemical Formula":"C29H35NO2",
                "Half Life":"18 hours",
                "Adverse Effects":"Abdominal or stomach pain or uterine cramping. Back pain. Diarrhea. Dizziness. Headache. Nausea or vomiting.",
                "Food Interactions":"Avoid eating grapefruit or drinking grapefruit juice while using this  medication unless your doctor or pharmacist says you may do so safely.",
                "Dosage form":"-Oral Initial dose: 300 mg orally once a day Maximum dose: 1200 mg or 20 mg/kg once a day",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Oriahnn": {
                "Drug Name": "Oriahnn",
                "Receptor": "GnRH receptors in the pituitary gland",
                "LogP Value": "4.01.",
                "Chemical Formula":"C32H29F5N3O5Na",
                "Half Life":"5.9 hours ± 2.1",
                "Adverse Effects":"Elevated blood pressure; Osteoporosis; Gallbladder problems; Mood disorder; Changes in laboratory tests; Hepatic impairment and transaminase elevations; High blood sugar; Alopecia; Hair loss; Thromboembolic disorders and vascular events; Allergic reaction; Changes in lipid parameters Severe headache",
                "Food Interactions":"•Avoid eating grapefruit or drinking grapefruit juice	",
                "Dosage form":"morning capsule: white and yellow, imprinted with “EL300 AM”; evening capsule: white and light blue, imprinted with “EL300 PM”",
                "Marketed preparation":"One capsule contains a combination of 3 medications: elagolix, estradiol, and norethindrone.",
                "Alternatives":"Lupron Depot (leuprolide); Leuprolide"  
            },
            "fadrozole ": {
                "Drug Name": "fadrozole ",
                "Receptor": ".androgen antagonist with greater affinity for the androgen receptor",
                "LogP Value": "3.20",
                "Chemical Formula":"3.20",
                "Half Life":"10.5 h ",
                "Adverse Effects":"–nausea flashes ",
                "Food Interactions":"no interacton with food",
                "Dosage form":"Single injection of fadrozole at a dose of 50 µg/kg at time -72 h had a slight but significantly stimulatory effect on spontaneous LH secretion (18.3 ng/ml)",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Leuprolide ": {
                "Drug Name": "Leuprolide ",
                "Receptor": "potent gonadotropin-releasing hormone receptor (GnRHR) agonist ",
                "LogP Value": "-2.7",
                "Chemical Formula":"C59H84N16O12",
                "Half Life":"3 hrs",
                "Adverse Effects":"pituitary gland problems; Acne, itching, rash, white scales (seborrhea);  Cold symptoms such as stuffy nose, sneezing, sore throat, cough with or without mucus; Fractures, ligament sprain; Fever, tiredness, not feeling well Stomach pain, nausea, vomiting, diarrhea, constipation; Wheezing, chest tightness, trouble breathing; Breast tenderness, hot flashes, sweating; Dizziness, sleep problems, mood changes; Headache, general pain; Vaginal swelling, itching, or discharge; Weight changes; Decreased testicle size  Irregular menstrual periods, decreased interest in sex; or Redness, pain, swelling, or oozing where the medicine was injected",
                "Food Interactions":"•Eat a plant-based diet (vegetables, fruit, beans, whole grains) Choose foods low in fat and low in salt. Get to and stay at a healthy weight.	",
                "Dosage form":"intramuscular kit (22.5 mg/3 months; 30 mg/4 months; 45 mg/6 months; 7.5 mg/month; pediatric 11.25 mg/3 months; pediatric 11.25 mg/month; pediatric 15 mg/month; pediatric 30 mg/3 months; pediatric 45 mg/6 months; pediatric 7.5 mg/month)",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "asoprisnil": {
                "Drug Name": "asoprisnil",
                "Receptor": ".selective progesterone receptor modulator",
                "LogP Value": "0.05",
                "Chemical Formula":"C28H35NO4",
                "Half Life":"32.4 ± 6.3 hours",
                "Adverse Effects":"Hot flashes",
                "Food Interactions":"no interaction with food",
                "Dosage form":"tab- 10 mg, 25 mg ",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ulipristal": {
                "Drug Name": "Ulipristal",
                "Receptor": "progesterone receptors",
                "LogP Value": "	4.62",
                "Chemical Formula":"C30H37NO4",
                "Half Life":"C30H37NO4",
                "Adverse Effects":".severe lower abdominal pain (3 to 5 weeks after taking ulipristal) rash, itching, hives, or swelling of the eyes, face, tongue, throat",
                "Food Interactions":"Avoid grapefruit juice if ulipristal is given chronically for hormonal conditions	",
                "Dosage form":"tablet- 30mg (ella, Logilia)",
                "Marketed preparation":"Ulipristal acetate, sold under the brand name Ella ",
                "Alternatives":"	Levonorgestrel"  
            },
            "vilaprisan ": {
                "Drug Name": "vilaprisan ",
                "Receptor": "Receptor-selective progesterone receptor modulator",
                "LogP Value": "4.13",
                "Chemical Formula":"C27H29F5O4S",
                "Half Life":"34 hours  ",
                "Adverse Effects":"ovarian cysts, headaches, and hot flushes.",
                "Food Interactions":"Food intake has a negligible impact on the PK of vilaprisan",
                "Dosage form":"-2 or 5 mg immediate-release tablets, and the validated liquid chromatography-tandem",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Goserelin": {
                "Drug Name": "Goserelin",
                "Receptor": "-synthetic decapeptide analogue of gonadotropin releasing hormone that acts as a partial agonist of the gonadotropin receptors in the pituitary that regulate luteinizing hormone (LH) and follicle   stimulating hormone (FSH) secretion.",
                "LogP Value": " 1.95",
                "Chemical Formula":"C59H84N18O14",
                "Half Life":"2.3 hours",
                "Adverse Effects":"an allergic reaction that can cause a rash, shortness of breath, redness or swelling of the face and dizziness. Some allergic reactions can be life threatening, alert your healthcare team if notice any of these symptoms. Development of a pituitary tumour, this is very rare",
                "Food Interactions":"–Avoid drinking alcohol. It can increase your risk of bone loss while you are being treated with Zoladex. Avoid smoking, which can increase your risk of bone loss, stroke, or heart  problems.",
                "Dosage form":"implant- ZOLADEX, at a dose of 3.6 mg, should be administered subcutaneously every 28 days into the anterior abdominal wall below the navel line using an aseptic technique.",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Triplorelin ": {
                "Drug Name": "Triplorelin ",
                "Receptor": "it binds with high affinity to the GnRH receptor on anterior pituitary cells, where it acts as an agonist",
                "LogP Value": "1.73",
                "Chemical Formula":"C64-H82-N18-O13",
                "Half Life":"The half lives are estimated to be 6 minutes, 45 minutes, and 3 hours",
                "Adverse Effects":"headache.Heartburn. Constipation. Hot flashes (a sudden wave of mild or intense body heat), sweating, or clamminess. Decreased sexual ability or desire. Mood changes such as crying, irritability, impatience, anger, and aggression. Leg or joint pain. Breast pain.",
                "Food Interactions":"No interactions found/established	",
                "Dosage form":"Reconstitution results in suspension for IM injection 3.75mg/vial  11.25mg/vial 22.5mg/vial",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Tamoxifen": {
                "Drug Name": "Tamoxifen",
                "Receptor": "estrogen receptors",
                "LogP Value": "6.35 ",
                "Chemical Formula":"C26H29NO",
                "Half Life":"5 to 7 days",
                "Adverse Effects":"difficulty breathing; swelling of your face, lips, tongue, or throat",
                "Food Interactions":"avoid grapefruit and tangerines",
                "Dosage form":"oral solution (10 mg/5 mL), oral tablet (10 mg; 20 mg)",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            " Acetaminophen ": {
                "Drug Name": "Acetaminophen ",
                "Receptor": "acts on the central nervous system by inhibiting the production of prostaglandins.",
                "LogP Value": "9.5",
                "Chemical Formula":"C8H9NO2",
                "Half Life":"2 to 3 hr  ",
                "Adverse Effects":"red, peeling or blistering skin -rash. -hives. -itching -swelling of the face, throat, tongue, lips, eyes, hands, feet, ankles, or lower legs. -hoarseness -difficulty breathing or swallowing.",
                "Food Interactions":"Acetaminophen does not typically have significant food interactions. However, taking it with food or milk may help reduce the risk of stomach upset or irritation.",
                "Dosage form":"Tablet 325/500 mg Capsule 500 mg Intravenous 10 mg/ml",
                "Marketed preparation":"HABIMOL-125 TYLENOL PAIN RELIF",
                "Alternatives":"."     
            },
            " cisplatin ": {
                "Drug Name": "Cisplatin  ",
                "Receptor": "Acts by binding to DNA",
                "LogP Value": "-2.19",
                "Chemical Formula":"Cl2H6N2Pt",
                "Half Life":"20 to 30 minutes ",
                "Adverse Effects":"Kidney damage, Neuropathy,Nausea & Vomiting, Hearing loss,Bone marrow suppression ",
                "Food Interactions":"Cisplatin is generally administered intravenously in a clinical setting & is not typically affected by food interaction	",
                "Dosage form":"Injection 50 mg  ;Solution 1 mg/ml",
                "Marketed preparation":"CISPLAT, PLATINEX, CYTOPLATIN-50, CISPIASIRE-50",
                "Alternatives":"Fluconazole, Neupogen"     
            },
            " Ibuprofen   ": {
                "Drug Name": "Ibuprofen   ",
                "Receptor": "binds to and inhibits both cyclooxygenase-1 (COX-1) and cyclooxygenase-2 (COX-2) enzymes",
                "LogP Value": "4.91 ",
                "Chemical Formula":"C13H18O2",
                "Half Life":" 2 to 4 hours ",
                "Adverse Effects":"Headache -Feeling dizzy. -Feeling sick (nausea) Stick to simple meals. -Being sick (vomiting) -Wind.  -Indigestion",
                "Food Interactions":"Taking ibuprofen with food can help reduce the risk of stomach irritation or upset. It's generally recommended to take ibuprofen with a meal or snack to minimize any potential gastrointestinal discomfort.                ",
                "Dosage form":"Suspension 400 mg Capsule, liquid filled 600 mg Capsule 400.000 mg",
                "Marketed preparation":"Ibruwell-400  BRUFEN 200 Ibugesic-200 BRUFEN 400 Algofren",
                "Alternatives":"Celebrex, Qdolo, Qutenza, Voltaren gel, Tylenol"     
            }, 
            " Carboplatin  ": {
                "Drug Name": "Carboplatin   ",
                "Receptor": "BindingtoDNAanddisruptingitsreplicatio",
                "LogP Value": "-2.6",
                "Chemical Formula":"C6H12N2O4Pt",
                "Half Life":"1.1to2hours",
                "Adverse Effects":"Numbnessortinglinginthehand/feet,Mouthsore,Yellowing eyes/skin,Darkurine,Unusualtiredness,Signsofkidneyproblems",
                "Food Interactions":"Carboplatin,likeCisplatinisoftenadministeredintravenouslyina clinicalsettinganddoesnothavesignificantfoodinteraction	",
                "Dosage form":"Injection150mg/15ml; Solutionconcentrate10mg",
                "Marketed preparation":"CARBOWEL,NAPROPLAT,KEMOCARB,CARBOKEM,CARBOPIN 150",
                "Alternatives":"Fluorouracil,Doxorubicin"    
            },
            " Naproxen   ": {
                "Drug Name": " Naproxen    ",
                "Receptor": "inhibiting the activity of the enzyme cyclooxygenase (COX), which is involved in the production of prostaglandins.                ",
                "LogP Value": "3.37                ",
                "Chemical Formula":"C14H14O3",
                "Half Life":" 12 to 15 hours.                ",
                "Adverse Effects":"Confusion. -Headache -Ringing in the ears. -Changes in vision. -Feeling sleepy or tired.   -Feeling dizzy. -Rashes.",
                "Food Interactions":"Taking naproxen with food or milk can help reduce the risk of stomach upset.                ",
                "Dosage form":" Tablet 550 mg  Capsule, liquid filled 275 mg Tablet, coated 275 mg                 ",
                "Marketed preparation":"WELLXEN 250  Naprozen-D  Karnip Plus  XEN-DO Napx D Forte Naprosyn",
                "Alternatives":"Diclofenac, Celebrex, Meloxicam, Prednisone, Remicade"    
            }, 
            " Paclitaxel ": {
                "Drug Name": "Paclitaxel",
                "Receptor": "BindingtoBeta-tubulinsubunitswithinmicrotubule",
                "LogP Value": "4",
                "Chemical Formula":"C47H51NO14",
                "Half Life":"0.55hr",
                "Adverse Effects":"Nausea,Vomiting,Diarrhoea,Mouthsore,Muscle/jointpain, Tingling/burningofthehands/feet,Flushing,DizzinessorDrowsiness",
                "Food Interactions":"Paclitaxel,achemotherapymedication,istypicallyadministered intravenouslyandisnotsignificantlyaffectedbyfoodinteractions",
                "Dosage form":"Injection,powder,forsuspension5mg/ml Solution6.00mg Powder100mg",
                "Marketed preparation":"TAXOL,PACLISAL-300,SOFTAXEL,PAC-DELTA,PACSHIL-260,NABEXOL,NAB, PACLITERO",
                "Alternatives":"Enhertu,Trodelvy"    
            }, 
            " Ondansetron  ": {
                "Drug Name": "Ondansetron ",
                "Receptor": "binds to serotonin 5-HT3 receptors                ",
                "LogP Value": "3.5",
                "Chemical Formula":"C18H19N3O",
                "Half Life":"3 to 4 hours ",
                "Adverse Effects":"severe constipation, stomach pain, or bloating headache with chest pain -fast or pounding heartbeats; -jaundice -blurred vision -high levels of serotonin in the body",
                "Food Interactions":"food does not significantly affect its absorption. Therefore, there are no specific food interactions of concern with Ondansetron.                ",
                "Dosage form":"Solution 4 mg / 5 mL Tablet 8 mg Injection, solution 4mg",
                "Marketed preparation":"Onryte ONDANICS ENDWELL Helicoset Toloxy",
                "Alternatives":"Metoclopramide, Prochlorperazine, Phenergan, Meclizine, Aprepitant, Hyoscine"    
            }, 
            " Topotecan   ": {
                "Drug Name": "Topotecan ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."    
            }, 
            " Metoclopramide    ": {
                "Drug Name": " Metoclopramide   ",
                "Receptor": "binds to dopamine D2 receptors in the chemoreceptor trigger zone (CTZ) and the gastrointestinal tract. ",
                "LogP Value": " 2.2",
                "Chemical Formula":"C14H22ClN3O2",
                "Half Life":"5-6 hours                ",
                "Adverse Effects":"Dizziness, Dark urine, Diarrhea, Changes in menstruation, Decreased appetite, Drowsiness, Loss of strength or energy, Trouble sleeping, Chills, Decreased urine output, Heart arrhythmia                ",
                "Food Interactions":"Metoclopramide's absorption is reduced when taken with food, so it's typically recommended to take it 30 minutes before meals.                 ",
                "Dosage form":"Tablet 15 mg Injection, solution 10 mg Solution 400.000 mg",
                "Marketed preparation":"Livpromide Metoprove METOPRAM EMENORM VOMINORN",
                "Alternatives":"Sumatriptan,Imitrex,."    
            }, 
            " Gemcitabine  ": {
                "Drug Name": "Gemcitabine ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."    
            }, 
            " Dexamethasone  ": {
                "Drug Name": " Dexamethasone  ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."    
            }, 
            " Oxaliplatin   ": {
                "Drug Name": "  Oxaliplatin ",
                "Receptor": "itactsasaplatinum-basedchemotherapyagentthatformsintrastrandand, interstrandDNAcross-links",
                "LogP Value": "-0.45",
                "Chemical Formula":"C8H14N2O4Pt",
                "Half Life":"16.8hr",
                "Adverse Effects":"-Fever,Fatigue,Nausea,Emesis -Decreasedsenseoftouch -Nausea -vomiting -Diarrhoea -Constipation -Paininthehandsorfeet; Increasedsensitivity,especiallytocold",
                "Food Interactions":"Oxaliplatinisanotherchemotherapymedicationtypically administeredintravenously.It’snotsignificantlyaffectedbyfoodinteractions ",
                "Dosage form":"Solutionconcentrate5mg Powder,forsolution5mg/ml Injection,powderforsolution50mg",
                "Marketed preparation":"OXITAN,OXASAL-50,CELDACH-100,VOXATIN,OXIPLAT-100",
                "Alternatives":"Opdivo,Xeloda"    
            }, 
            " Lorazepam    ": {
                "Drug Name": "Lorazepam    ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."    
            }, 
            " Docetaxel": {
                "Drug Name": "Docetaxel",
                "Receptor": "Bindstomicrotubuleswithincells",
                "LogP Value": "4.1 ",
                "Chemical Formula":"C43H53NO14",
                "Half Life":"11to18hrs",
                "Adverse Effects":"Stomachproblem,Fever,vomiting,stomachcramps,WateryDiarrhea",
                "Food Interactions":"Therearenospecificfoodinteractionswithdocetaxel,a chemotherapymedicationusedtotreatvarioustypesofcancer                    ",
                "Dosage form":"Injection40mg/ml Solution20mg/1ml Solution/drops2mg/ml",
                "Marketed preparation":"Taxocure,Docxane-20,Docesal-120,Docemax-120,Docetax-80, Docetero-80,Docet",
                "Alternatives":"Enhertu,Trodelvy"    
            }, 
            " Diphenhydramine   ": {
                "Drug Name": "Diphenhydramine   ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."    
            }, 
            " Irinotecan ": {
                "Drug Name": " Irinotecan",
                "Receptor": "BindingtotopoisomeraseI-DNAcomplex",
                "LogP Value": "2.78",
                "Chemical Formula":"C33H39CIN4O6",
                "Half Life":"6to12h",
                "Adverse Effects":".Acutecholinergicsyndrome,Diarrhoea,Swearing,Abdominalpain,Wateryeye",
                "Food Interactions":"-Irinotecan,achemotherapymedicationcanbeaffectedbyfood interactions,particularlyhigh-fatmeals	",
                "Dosage form":"Solution20.00mg Injection20mg/ml Injection,solution,concentrate20mg/1ml",
                "Marketed preparation":"RINOTEC,IRITERO-40,Onivyde,Rinowel,Irinotel,Irobenz-40",
                "Alternatives":"Opdivo,Oxaliplatin."    
            },  

        // Create a new table for drug details
        var drugTable = document.createElement("table");
        drugTable.classList.add("drug-details");
        drugTable.innerHTML = `
        <table border="1" align="center">
        <thead>
            <tr>
                <th colspan="11">
                    <h3 style="text-align: center;">${drugName} </h3>
                </th>
            </tr>
            <tr>
                <th>Drug Name</th>
                <th>Receptor</th>
                <th>LogP Value</th>
                <th>Chemical Formula</th>
                <th>Half Life</th>
                <th>Adverse Effects</th>
                <th>Food Interactions</th>
                <th>Dosage Forms</th>
                <th>Marketed Preparations</th>
                <th>Alternatives</th>
            </tr> 
        </thead>
        <tbody>
            <tr>
                <td>${drugDetails[drugName]["Drug Name"]}</td>
                <td>${drugDetails[drugName]["Receptor"]}</td>
                <td>${drugDetails[drugName]["LogP Value"]}</td>
                <td>${drugDetails[drugName]["Chemical Formula"]}</td>
                <td>${drugDetails[drugName]["Half Life"]}</td>
                <td>${drugDetails[drugName]["Adverse Effects"]}</td>
                <td>${drugDetails[drugName]["Food Interactions"]}</td>
                <td>${drugDetails[drugName]["Dosage Form"]}</td>
                <td>${drugDetails[drugName]["Marketed Preparation"]}</td>
                <td>${drugDetails[drugName]["Alternatives"]}</td>
            </tr>
        </tbody>
    </table>
    
        `;

        // Clear previous drug details tables
        var container = document.querySelector(".container");
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Append the drug details table below the main table
        container.appendChild(drugTable);
    }
});
